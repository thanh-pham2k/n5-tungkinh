# M08.3: AWS Step Functions (Workflow Orchestration)

## 3. AWS Step Functions – Workflow Orchestration

### 3.1 Khi nào cần Step Functions?

Một quy trình order processing có nhiều bước phụ thuộc nhau:

```text
Create Order
     |
     v
Check Inventory
     |
     v
Reserve Stock
     |
     v
Charge Payment
     |
     +── Success → Create Shipment
     |
     └── Failure → Retry → Compensate
```

Step Functions quản lý:

- Workflow state.

- Retry và timeout.

- Error handling.

- Branching.

- Parallel execution.

- Execution history.

Why Step Functions instead of SQS?

SQS truyền công việc giữa producer và consumer. Step Functions điều phối thứ tự, trạng thái và nhánh của nhiều bước nghiệp vụ.

### 3.2 Standard vs Express Workflow

| Standard | Express |
| --- | --- |
| Tối đa 1 năm | Tối đa khoảng 5 phút |
| Workflow dài | Workflow ngắn, tần suất lớn |
| Tính phí theo state transition | Tính phí theo execution/duration |
| Approval, order, ETL | IoT, streaming, mobile |

### 3.3 Các State quan trọng

| State | Chức năng |
| --- | --- |
| Task | Thực hiện công việc |
| Choice | Rẽ nhánh |
| Parallel | Chạy song song |
| Map | Xử lý danh sách |
| Wait | Chờ |
| Pass | Truyền hoặc biến đổi dữ liệu |
| Succeed | Kết thúc thành công |
| Fail | Kết thúc thất bại |

Retry và Catch:

```text
Payment Task
     |
   Error
     |
   Retry
     |
 Still Error
     |
   Catch
     |
Compensation
```

### Quiz 03 – Workflow Orchestration

```quiz-deck
INT-013 | single_choice | Một hệ thống order processing gồm kiểm tra tồn kho, thanh toán, tạo shipment và compensation khi lỗi. Cần quản lý state, retry và branching. Chọn gì? | SQS Standard | SNS Standard | Kinesis Firehose | AWS Step Functions | 4 | Step Functions quản lý workflow nhiều bước, state, retry và branching. SQS/SNS truyền message. Firehose delivery streaming data.
INT-014 | single_choice | Một approval workflow có thể chờ người dùng phê duyệt trong nhiều ngày. Loại Step Functions nào phù hợp? | Express Workflow | Standard Workflow | Kinesis Data Streams | SQS Delay Queue | 2 | Standard hỗ trợ workflow dài đến một năm. Express chỉ chạy ngắn. Kinesis không điều phối approval. SQS Delay Queue tối đa 15 phút.
INT-015 | single_choice | Một IoT platform cần chạy workflow ngắn với tần suất rất cao, mỗi execution chỉ mất vài giây. Chọn gì? | Step Functions Express | Step Functions Standard bắt buộc | Amazon MQ | SQS FIFO | 1 | Express phù hợp workflow ngắn và throughput cao. Standard thiên về workflow dài. MQ và SQS FIFO không thay thế workflow orchestration.
INT-016 | single_choice | Một workflow cần kiểm tra giá trị inventory và chọn nhánh InStock hoặc OutOfStock. State nào phù hợp? | Parallel | Map | Choice | Wait | 3 | Choice State dùng để branching. Parallel chạy nhiều nhánh đồng thời. Map lặp danh sách. Wait tạm dừng workflow.
INT-017 | single_choice | Một workflow cần xử lý 500 items trong danh sách bằng cùng một logic. State nào phù hợp nhất? | Fail | Pass | Wait | Map | 4 | Map State xử lý collection items. Fail kết thúc lỗi. Pass chuyển dữ liệu. Wait trì hoãn.
INT-018 | single_choice | Một payment task bị lỗi tạm thời và cần thử lại trước khi chuyển sang compensation. Nên dùng gì? | SNS Topic | Retry và Catch trong Step Functions | S3 Lifecycle | Route 53 Failover | 2 | Retry xử lý lỗi tạm thời và Catch điều hướng khi retry thất bại. Các lựa chọn còn lại không điều phối task error handling.
```
