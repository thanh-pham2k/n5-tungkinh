# M08.2: SNS, Fanout Pattern & EventBridge

## 2. SNS, Fanout và EventBridge

### 2.1 Amazon SNS

SNS là managed Publish/Subscribe service.

```text
OrderCreated
     |
     v
  SNS Topic
     |
     +── Email Subscriber
     +── Inventory Subscriber
     +── Analytics Subscriber
```

Một event được gửi đến nhiều subscribers.

Hỗ trợ SQS, Lambda, HTTP/HTTPS, Email, SMS, Mobile Push và Firehose.

### 2.2 SNS Standard vs FIFO

| Standard | FIFO |
| --- | --- |
| Throughput cao | Ordering |
| At-least-once | Deduplication |
| Best-effort ordering | Ordered delivery |
| Nhiều subscriber types | Trong tài liệu: kết hợp SQS FIFO |

Message Filtering: Subscriber chỉ nhận message phù hợp filter policy.

Ví dụ: Inventory Queue chỉ nhận OrderCreated, Payment Queue chỉ nhận PaymentFailed.

### 2.3 SNS + SQS Fanout

Đây là pattern rất quan trọng trong SAA-C03.

Why SNS + SQS instead of SNS trực tiếp?

SNS phân phối event. SQS giữ message cho consumer khi worker chậm hoặc tạm ngừng.

### 2.4 Amazon EventBridge

EventBridge là serverless Event Bus, định tuyến event theo nội dung.

```text
AWS / SaaS / Custom Events
           |
           v
       Event Bus
           |
           v
       Event Rule
           |
     +-----+------+
     |            |
   Lambda     Step Functions
```

Ba loại Event Bus:

- Default: AWS service events.

- Partner: SaaS events.

- Custom: Application events.

Ví dụ event rule:

```text
{
  "source": ["aws.ec2"],
  "detail": {
    "state": ["terminated"]
  }
}
```

Chỉ định tuyến event EC2 có state terminated.

EventBridge còn hỗ trợ scheduled events và Schema Registry.

### 2.5 SNS vs EventBridge

| SNS | EventBridge |
| --- | --- |
| Pub/Sub | Event routing |
| Fanout đơn giản | Content-based filtering |
| Topic/subscribers | Event bus/rules/targets |
| Notifications | AWS/SaaS/custom integrations |

When to use?

- Một event cần gửi đến nhiều consumers → SNS.

- Event cần lọc theo field, định tuyến phức tạp → EventBridge.

### Quiz 02 – SNS và EventBridge

```quiz-deck
INT-007 | single_choice | OrderCreated phải được xử lý độc lập bởi Email, Inventory và Analytics. Mỗi service cần queue riêng để retry khi lỗi. Chọn kiến trúc nào? | Một SQS queue cho cả ba service | API gọi tuần tự ba service | SNS Topic fanout đến ba SQS queues | Một Lambda xử lý tất cả | 3 | SNS + SQS fanout cung cấp một bản message cho mỗi queue và consumer xử lý độc lập. Một queue chung không broadcast. Gọi tuần tự hoặc gom Lambda làm tăng coupling.
INT-008 | single_choice | Một công ty muốn route event EC2 terminated đến Lambda nhưng bỏ qua các event EC2 khác. Chọn gì? | EventBridge Rule lọc theo event detail | SQS Long Polling | SNS không có filtering | S3 Lifecycle | 1 | EventBridge hỗ trợ content-based event filtering. Long Polling và Lifecycle không route event theo nội dung.
INT-009 | single_choice | Một SaaS application muốn gửi events đến AWS event bus và định tuyến đến nhiều AWS targets. Chọn gì? | SQS FIFO | AWS Batch | Amazon MQ | EventBridge Partner Event Bus | 4 | Partner Event Bus phù hợp SaaS integration. SQS FIFO là queue. Batch chạy jobs. MQ hỗ trợ traditional broker protocols.
INT-010 | single_choice | Một hệ thống SNS có subscriber chỉ muốn nhận payment_failed thay vì mọi event. Cấu hình nào phù hợp? | Visibility Timeout | SNS Filter Policy | S3 Object Lock | CloudTrail Trail | 2 | SNS Filter Policy lọc message trước khi gửi đến subscriber. Visibility Timeout thuộc SQS. Object Lock và CloudTrail không thực hiện subscriber filtering.
INT-011 | single_choice | Một team cần kích hoạt Lambda định kỳ mỗi 5 phút bằng event schedule. Chọn gì? | EventBridge Schedule | SQS FIFO | SNS FIFO | Kinesis Video Streams | 1 | EventBridge hỗ trợ scheduled invocation. Các lựa chọn còn lại không phải công cụ scheduling phù hợp trong tài liệu.
INT-012 | single_choice | Producer cần gửi event đến nhiều services nhưng muốn mỗi service tự scale và không bị ảnh hưởng khi service khác ngừng hoạt động. Giải pháp tối ưu? | Gọi REST đồng bộ đến mọi service | Chỉ dùng một shared queue | SNS kết hợp SQS queue riêng cho từng service | Dùng ACM | 3 | SNS + SQS tạo fanout với queue độc lập, giúp consumer tự scale và retry. Shared queue không broadcast. REST đồng bộ tạo coupling. ACM không liên quan.
```
