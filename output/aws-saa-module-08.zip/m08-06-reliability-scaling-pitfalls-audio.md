# M08.6: Reliability, Scaling & Service Selection

## 6. Reliability, Scaling và Common Pitfalls

### 6.1 Idempotency

SQS Standard có thể gửi message trùng. FIFO cũng không loại bỏ nhu cầu thiết kế idempotency ở application.

Ví dụ:

```text
Message: payment_id = PAY123

Worker nhận PAY123
       |
       v
Check payment processed?
       |
   +---+---+
   |       |
  Yes      No
   |       |
 Skip    Process
```

Best practice: Dùng business identifier để tránh xử lý cùng một nghiệp vụ nhiều lần.

### 6.2 Retry và DLQ

```text
Consumer Failure
       |
       v
Visibility Timeout
       |
       v
Message Available Again
       |
       v
Retry
       |
       +── Success → Delete
       |
       └── Repeated Failure → DLQ
```

### 6.3 Scaling theo Queue Depth

```text
Queue Depth tăng
       |
       v
Auto Scaling Consumers
       |
       v
Processing Capacity tăng
       |
       v
Queue Depth giảm
```

Trade-off: Queue giúp buffer traffic, nhưng nếu producer liên tục gửi nhanh hơn consumer xử lý thì backlog vẫn tăng. Cần theo dõi queue depth và năng lực xử lý.

### 6.4 Common Pitfalls

| Sai lầm | Cách xử lý |
| --- | --- |
| Dùng SQS Standard khi cần strict ordering | SQS FIFO |
| Consumer không idempotent | Deduplicate theo business ID |
| Visibility Timeout quá ngắn | Tăng hoặc gia hạn timeout |
| Không DeleteMessage sau khi xử lý | Xóa sau khi thành công |
| Không có DLQ | Cấu hình DLQ |
| Dùng SNS trực tiếp khi cần queue bền vững | SNS + SQS |
| Dùng EventBridge thay work queue | SQS |
| Dùng Step Functions chỉ để truyền message | SQS/SNS |
| Dùng Amazon MQ cho cloud-native app không cần broker protocol | SQS/SNS/EventBridge |
| Dùng Firehose khi cần xử lý tức thời | Kinesis Data Streams |

### Quiz 06 – Reliability và Troubleshooting

```quiz-deck
INT-031 | single_choice | Một payment consumer xử lý lại cùng message sau khi worker crash. Làm sao tránh charge hai lần? | Tăng số workers | Tắt retry | Dùng SNS thay SQS | Thiết kế idempotency theo payment ID | 4 | Idempotency đảm bảo xử lý lặp không tạo thêm business side effects. Tăng worker hoặc tắt retry không đảm bảo correctness.
INT-032 | single_choice | Một worker xử lý SQS message thành công nhưng quên DeleteMessage. Điều gì có thể xảy ra? | Message có thể xuất hiện lại sau Visibility Timeout | Message chắc chắn tự biến mất ngay | Queue tự chuyển sang FIFO | SNS tự xóa message | 1 | SQS yêu cầu consumer delete message sau xử lý. Nếu không, message có thể xuất hiện lại khi Visibility Timeout hết.
INT-033 | single_choice | Một consumer có thời gian xử lý biến động từ 30 giây đến vài phút. Làm sao tránh message xuất hiện lại quá sớm? | Giảm retention | Chỉ tăng queue depth | Điều chỉnh Visibility Timeout và ChangeMessageVisibility | Dùng ACM | 3 | Visibility Timeout và ChangeMessageVisibility giúp phù hợp thời gian xử lý. Retention và queue depth không giải quyết premature redelivery.
INT-034 | single_choice | Một hệ thống SQS có backlog tăng nhanh trong giờ cao điểm. Team muốn tăng processing capacity tự động. Chọn gì? | Route 53 Geolocation | Auto Scaling consumers theo queue depth | S3 Glacier | ACM Renewal | 2 | Scaling consumers theo queue depth giúp xử lý backlog. Các lựa chọn khác không tăng consumer capacity.
INT-035 | single_choice | Một service cần retry các message thất bại nhưng không muốn poison message chặn luồng xử lý. Chọn gì? | Chỉ dùng Long Polling | Tăng retention vô hạn | Tắt logging | DLQ với redrive policy | 4 | DLQ tách poison messages sau nhiều lần thất bại. Long Polling và retention không cô lập message lỗi.
INT-036 | single_choice | Một team muốn lưu payload 2 MB trong SQS nhưng message size giới hạn 256 KB. Giải pháp phù hợp? | Lưu payload trong S3 và gửi object reference qua SQS | Chia payload thành SNS Email | Chuyển sang ACM | Tắt encryption | 1 | S3 lưu payload lớn và SQS truyền reference. SNS Email, ACM và encryption settings không giải quyết message size.
INT-037 | single_choice | Một hệ thống dùng EventBridge để buffer hàng triệu background jobs với worker retry và DLQ. Dịch vụ nào phù hợp hơn cho work queue? | AWS AppSync | AWS Certificate Manager | Amazon SQS | Route 53 | 3 | SQS được thiết kế cho buffering, retry, DLQ và worker processing. EventBridge tập trung event routing. AppSync, ACM và Route 53 không phải work queue.
```
