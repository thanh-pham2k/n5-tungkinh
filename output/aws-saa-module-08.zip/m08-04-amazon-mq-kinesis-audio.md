# M08.4: Amazon MQ & Kinesis Streaming

## 4. Amazon MQ và Kinesis Streaming

### 4.1 Amazon MQ

Amazon MQ là managed traditional message broker, hỗ trợ ActiveMQ và RabbitMQ.

Phù hợp khi:

- Hệ thống cũ đang sử dụng broker protocols.

- Không muốn rewrite messaging layer.

- Cần migration nhanh.

Why Amazon MQ instead of SQS?

Nếu ứng dụng legacy phụ thuộc vào ActiveMQ/RabbitMQ protocols, Amazon MQ giảm thay đổi code. Với cloud-native application mới, thường ưu tiên SQS, SNS hoặc EventBridge.

### 4.2 Amazon Kinesis

Kinesis xử lý dữ liệu streaming liên tục.

| Dịch vụ | Mục đích |
| --- | --- |
| Kinesis Data Streams | Real-time ingestion, processing, replay |
| Kinesis Data Firehose | Delivery streaming data đến destinations |
| Kinesis Data Analytics | Phân tích stream bằng SQL/Flink |
| Kinesis Video Streams | Ingest video từ thiết bị |

### 4.3 Kinesis Data Streams

```text
IoT Devices / Clickstream
          |
          v
    Kinesis Stream
          |
     +----+-----+
     |          |
Fraud Detection  Analytics
```

Đặc điểm:

- Nhiều consumer cùng đọc.

- Ordering trong một shard.

- Retention từ 1 đến 365 ngày.

- Replay dữ liệu.

- Real-time processing.

Theo mô hình shard được mô tả trong tài liệu, một shard hỗ trợ khoảng 1 MB/s input và 2 MB/s output.

### 4.4 Kinesis Data Firehose

```text
Application Logs
       |
       v
Kinesis Data Firehose
       |
       v
Lambda Transformation
       |
       v
Amazon S3 / Redshift / OpenSearch
```

Firehose tự động scale và hỗ trợ buffering.

Trade-off: Firehose phù hợp near real-time delivery, không phải lựa chọn ưu tiên khi cần xử lý từng record tức thời.

### 4.5 SQS vs Kinesis

| SQS | Kinesis Data Streams |
| --- | --- |
| Work queue | Streaming platform |
| Consumer xử lý rồi xóa message | Nhiều consumer đọc stream |
| Retention tối đa 14 ngày | Retention đến 365 ngày |
| Background jobs | Real-time analytics |
| Decoupling đơn giản | Replay và stream processing |

### Quiz 04 – MQ và Kinesis

```quiz-deck
INT-019 | single_choice | Một doanh nghiệp đang sử dụng RabbitMQ và muốn migrate lên AWS mà không rewrite messaging protocol. Chọn gì? | SQS Standard | Amazon MQ | EventBridge | Kinesis Firehose | 2 | Amazon MQ hỗ trợ RabbitMQ/ActiveMQ compatibility, phù hợp legacy migration. SQS và EventBridge dùng mô hình khác. Firehose dùng cho stream delivery.
INT-020 | single_choice | Một hệ thống clickstream cần nhiều consumers đọc cùng dữ liệu và có thể replay events trong nhiều ngày. Chọn gì? | SQS Standard | SNS Email | AWS Batch | Kinesis Data Streams | 4 | Kinesis Data Streams hỗ trợ multiple consumers và retention/replay. SQS là work queue. SNS Email không lưu replayable stream. Batch chạy jobs.
INT-021 | single_choice | Một công ty muốn tự động đưa application logs vào S3 và cho phép Lambda transform trước khi lưu, không muốn quản lý shards. Chọn gì? | Kinesis Data Firehose | SQS FIFO | Amazon MQ | Step Functions Standard | 1 | Firehose hỗ trợ managed stream delivery, buffering và Lambda transformation. SQS/MQ là messaging. Step Functions điều phối workflow.
INT-022 | single_choice | Một fraud detection platform cần phân tích transaction stream real-time bằng Apache Flink. Dịch vụ nào phù hợp theo tài liệu? | Amazon MQ | SNS | Kinesis Data Analytics | SQS Delay Queue | 3 | Kinesis Data Analytics hỗ trợ Apache Flink và streaming analytics. MQ/SNS/SQS không cung cấp stream analytics engine tương đương.
INT-023 | single_choice | Một công ty cần ingest video liên tục từ camera an ninh và phục vụ video analytics. Chọn gì? | Kinesis Firehose | Kinesis Video Streams | SQS FIFO | SNS Standard | 2 | Kinesis Video Streams dành cho video ingestion. Firehose phục vụ data delivery. SQS và SNS là messaging services.
INT-024 | single_choice | Một hệ thống cần xử lý background jobs với retry, DLQ và consumer scaling theo queue depth. Không cần replay stream. Chọn gì? | Kinesis Data Streams | Kinesis Video Streams | Kinesis Data Analytics | Amazon SQS | 4 | SQS phù hợp work queue, retry, DLQ và queue-depth scaling. Kinesis phục vụ streaming, replay hoặc video.
```
