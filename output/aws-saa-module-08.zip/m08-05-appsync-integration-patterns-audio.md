# M08.5: AWS AppSync & Integration Patterns

## 5. AWS AppSync và Integration Patterns

### 5.1 AWS AppSync

AppSync là managed GraphQL service.

Hỗ trợ:

- GraphQL Query/Mutation.

- Real-time Subscription.

- Offline synchronization.

- Conflict resolution.

- DynamoDB, Lambda, HTTP API, RDS và OpenSearch.

```text
Mobile Client
      |
      v
AWS AppSync GraphQL
      |
      v
Resolver → DynamoDB
      |
      v
Subscription → Client Update
```

When to use?

Mobile/web application cần GraphQL API, real-time updates và offline-first experience.

### 5.2 Bốn Integration Patterns

| Pattern | Cơ chế | Use case |
| --- | --- | --- |
| Synchronous | Client chờ response | API cần kết quả ngay |
| Asynchronous | Producer không chờ consumer | Background processing |
| Streaming | Dữ liệu liên tục, nhiều consumer | Real-time analytics |
| Workflow | Điều phối nhiều bước | Order/payment lifecycle |

Ví dụ e-commerce:

```text
Client
  |
  v
Order API
  |
  +── SQS → Background Processing
  |
  +── SNS → Multiple Subscribers
  |
  +── EventBridge → Event Routing
  |
  +── Step Functions → Payment Workflow
  |
  +── Kinesis → Real-time Analytics
```

Mỗi dịch vụ giải quyết một vấn đề khác nhau; không nên sử dụng tất cả nếu bài toán không yêu cầu.

### Quiz 05 – Integration Patterns

```quiz-deck
INT-025 | single_choice | Một mobile application cần GraphQL API, real-time subscriptions và offline synchronization. Chọn gì? | Amazon SQS | AWS Step Functions | AWS AppSync | Amazon MQ | 3 | AppSync hỗ trợ GraphQL, subscriptions và offline sync. SQS/MQ là messaging. Step Functions điều phối workflow.
INT-026 | single_choice | Một API cần trả kết quả xác thực ngay để client quyết định cho phép đăng nhập hay không. Pattern nào phù hợp? | Synchronous Request-Response | Asynchronous Queue | Streaming | Batch Processing | 1 | Client cần kết quả ngay nên synchronous phù hợp. Queue, streaming và batch không tối ưu cho immediate request-response.
INT-027 | single_choice | Một application cần xử lý email sau khi tạo order mà không làm client chờ email service. Chọn pattern nào? | Synchronous REST chaining | GraphQL Subscription | Video Streaming | Asynchronous Messaging | 4 | Asynchronous messaging giúp order API không chờ email service. Synchronous chaining tăng coupling. Subscription và video không giải quyết background email processing.
INT-028 | single_choice | Một hệ thống cần theo dõi clickstream liên tục và nhiều analytics consumers cùng đọc events. Pattern nào phù hợp? | Work Queue đơn giản | Streaming | Synchronous API | Human Approval Workflow | 2 | Streaming hỗ trợ continuous ingestion và multiple consumers. Work queue, synchronous API và approval workflow phục vụ mục tiêu khác.
INT-029 | single_choice | Một ứng dụng cần xử lý đơn hàng theo nhiều bước có nhánh lỗi, timeout và retry. Pattern nào phù hợp? | Workflow Orchestration | Chỉ dùng SNS Email | Chỉ dùng S3 | Chỉ dùng Route 53 | 1 | Workflow orchestration quản lý trạng thái, branching và retries. SNS/S3/Route 53 không điều phối nghiệp vụ nhiều bước.
INT-030 | single_choice | Một team muốn giảm coupling giữa producer và consumer khi consumer có thể tạm ngừng hoạt động. Chọn gì? | REST gọi trực tiếp | Shared database transaction | SQS Queue | CloudFront Cache | 3 | SQS lưu message để consumer xử lý sau, giảm coupling. REST và shared transaction tạo phụ thuộc. CloudFront là CDN.
```
