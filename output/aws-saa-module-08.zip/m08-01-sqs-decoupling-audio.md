# M08.1: Messaging Fundamentals (Amazon SQS & DLQ)

## 1. Messaging Fundamentals: SQS và Decoupling

### 1.1 Tại sao cần Message Queue?

Giả sử hệ thống e-commerce xử lý đơn hàng:

```text
Synchronous:
Order API → Email Service → Inventory Service
                 |
              Timeout
                 |
           Order API lỗi
```

Các service phụ thuộc trực tiếp vào nhau. Khi một service chậm hoặc lỗi, request có thể bị ảnh hưởng.

Giải pháp: Amazon SQS.

```text
Asynchronous:
Order API → SQS Queue → Worker
              |
         Buffer messages
              |
       Worker xử lý dần
```

SQS giúp:

- Decoupling: Producer không cần biết consumer.

- Buffering: Hấp thụ traffic spike.

- Reliability: Message được lưu trong queue.

- Retry: Xử lý lại khi consumer lỗi.

- Scaling: Tăng worker theo queue depth.

### 1.2 SQS Standard vs FIFO

| Tiêu chí | Standard | FIFO |
| --- | --- | --- |
| Throughput | Rất cao | Giới hạn hơn |
| Ordering | Best effort | Strict ordering |
| Delivery | At least once | Deduplication và ordering |
| Duplicate | Có thể xuất hiện | Hỗ trợ chống duplicate |
| Use case | Email, image processing | Order, inventory |

Lưu ý quan trọng: FIFO không đảm bảo business logic chỉ thực thi một lần trong mọi tình huống. Consumer vẫn nên idempotent.

Ví dụ:

```text
Standard:
Send:    A → B → C
Receive: A → C → B → B

FIFO:
Send:    A → B → C
Receive: A → B → C
```

FIFO đảm bảo thứ tự trong cùng Message Group ID.

### 1.3 Visibility Timeout

Khi consumer nhận message, SQS tạm ẩn message khỏi consumer khác.

```text
Receive → Invisible → Process → Delete
```

- Mặc định: 30 giây.

- Tối đa: 12 giờ.

- Có thể điều chỉnh bằng ChangeMessageVisibility.

Failure scenario:

```text
Visibility Timeout = 30s
Processing Time    = 60s

Worker A nhận message
       ↓
Sau 30s message xuất hiện lại
       ↓
Worker B cũng nhận message
       ↓
Duplicate processing
```

Solution: Tăng Visibility Timeout phù hợp, gia hạn khi cần và thiết kế consumer idempotent.

### 1.4 Dead Letter Queue (DLQ)

DLQ lưu các message thất bại nhiều lần.

```text
Main Queue
    |
    | Retry thất bại
    v
Dead Letter Queue
    |
    v
Investigate / Fix / Redrive
```

Ví dụ: maxReceiveCount = 5, message bị xử lý thất bại nhiều lần sẽ chuyển sang DLQ theo redrive policy.

### 1.5 Những tính năng cần nhớ

| Feature | Ý nghĩa |
| --- | --- |
| Long Polling | Chờ tối đa 20 giây, giảm empty responses |
| Message Retention | 1 phút–14 ngày, mặc định 4 ngày |
| Delay Queue | Trì hoãn tối đa 15 phút |
| Message Size | Tối đa 256 KB |
| Encryption | HTTPS, KMS |
| Auto Scaling | Scale consumer theo queue depth |

Với dữ liệu lớn hơn giới hạn message, lưu payload trong S3 và gửi object reference qua SQS.

### Quiz 01 – SQS Fundamentals

```quiz-deck
INT-001 | single_choice | Một hệ thống xử lý ảnh nhận 10000 requests trong vài phút. Worker không thể xử lý ngay toàn bộ. Giải pháp nào phù hợp nhất? | Tăng timeout API | Amazon SQS làm buffer giữa API và worker | Dùng ACM | Dùng Route 53 Weighted | 2 | SQS hấp thụ traffic spike và cho worker xử lý bất đồng bộ. Tăng timeout không giải quyết buffering. ACM và Route 53 không quản lý background jobs.
INT-002 | single_choice | Một consumer xử lý SQS message trong 90 giây nhưng Visibility Timeout chỉ 30 giây. Điều gì có thể xảy ra? | Message tự động bị xóa | SQS tăng timeout vô hạn | Message không thể retry | Message xuất hiện lại và bị xử lý trùng | 4 | Sau khi Visibility Timeout hết, message có thể được consumer khác nhận. Cần điều chỉnh timeout và thiết kế idempotency.
INT-003 | single_choice | Một ứng dụng gửi email marketing với throughput rất cao, không yêu cầu strict ordering. Chọn queue nào? | SQS Standard | SQS FIFO | Step Functions Standard | Amazon MQ | 1 | SQS Standard phù hợp throughput cao và không cần thứ tự tuyệt đối. FIFO có ordering nhưng throughput giới hạn hơn. Step Functions điều phối workflow. Amazon MQ dành cho broker compatibility.
INT-004 | single_choice | Một hệ thống cần xử lý cập nhật trạng thái đơn hàng theo đúng thứ tự trong cùng một order. Chọn gì? | SNS Standard | SQS Standard | SQS FIFO với Message Group ID phù hợp | Kinesis Firehose | 3 | FIFO hỗ trợ ordering trong Message Group ID. Standard không đảm bảo strict ordering. SNS Standard và Firehose không phải lựa chọn phù hợp cho ordered work queue.
INT-005 | single_choice | Một message liên tục thất bại vì payload không hợp lệ. Làm sao tránh retry vô hạn và hỗ trợ điều tra? | Tăng số worker | Cấu hình Dead Letter Queue | Tắt CloudWatch | Giảm message retention xuống 1 phút | 2 | DLQ tách poison messages khỏi main queue để điều tra và redrive sau khi sửa lỗi. Tăng worker hoặc giảm retention không xử lý nguyên nhân.
INT-006 | single_choice | Consumer thường xuyên nhận empty response khi polling SQS và gây nhiều API calls. Nên bật gì? | Long Polling | FIFO Deduplication | S3 Versioning | Lambda Provisioned Concurrency | 1 | Long Polling chờ message tối đa 20 giây và giảm empty responses. Các lựa chọn khác không tối ưu polling.
```
