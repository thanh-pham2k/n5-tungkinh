# M08.7: So sánh, Pitfalls & Cheatsheet Integration

# 7. AWS SAA-C03 – Scenario-Based Exam Practice

12 câu • Architecture • Troubleshooting • Reliability • Performance • Cost • Trade-offs

```quiz-deck
INT-EX01 | single_choice | Một e-commerce platform có Order API đồng bộ gọi Email Service và Inventory Service. Khi Email Service chậm, checkout latency tăng. Công ty muốn giảm coupling và giữ khả năng retry. Chọn gì? | Tăng timeout của Order API | Chuyển toàn bộ service sang một EC2 | SNS fanout đến các SQS queues riêng | Dùng Route 53 Failover | 3 | SNS + SQS cho phép các services xử lý độc lập và retry. Tăng timeout không giảm coupling. Gom service vào EC2 hoặc đổi DNS không giải quyết asynchronous processing.
INT-EX02 | single_choice | Một hệ thống tài chính xử lý nhiều updates của cùng transaction. Các updates phải được xử lý theo đúng thứ tự và tránh duplicate delivery trong phạm vi FIFO. Chọn gì? | SQS FIFO với Message Group ID theo transaction | SQS Standard | SNS Standard | Kinesis Firehose | 1 | SQS FIFO giữ thứ tự trong Message Group ID và hỗ trợ deduplication. Standard không đảm bảo ordering. SNS Standard và Firehose không phù hợp ordered work queue.
INT-EX03 | single_choice | Một Lambda consumer đọc SQS nhưng xử lý mất 2 phút, Visibility Timeout chỉ 30 giây. Monitoring cho thấy một message bị xử lý nhiều lần. Giải pháp nào tốt nhất? | Tắt DLQ | Giảm worker concurrency về 0 | Dùng Route 53 | Tăng hoặc gia hạn Visibility Timeout và bảo đảm idempotency | 4 | Timeout ngắn gây redelivery trước khi xử lý xong. Điều chỉnh timeout và idempotency xử lý nguyên nhân. Tắt DLQ hoặc workers không đảm bảo correctness.
INT-EX04 | single_choice | Một hệ thống cần gửi OrderCreated đến Billing, Inventory và Analytics. Mỗi service có tốc độ xử lý khác nhau và cần message durability khi worker tạm dừng. Chọn gì? | Một SQS queue dùng chung | SNS Topic kết hợp SQS queue riêng cho từng service | Chỉ dùng SNS Email | REST đồng bộ | 2 | SNS + SQS fanout bảo đảm mỗi service có queue riêng, xử lý độc lập. Queue chung không broadcast. SNS Email và REST không đáp ứng durability cho workers.
INT-EX05 | single_choice | Một doanh nghiệp muốn định tuyến events từ AWS, SaaS và custom applications dựa trên nội dung event đến Lambda hoặc Step Functions. Chọn gì? | Amazon EventBridge | Amazon MQ | SQS Long Polling | Kinesis Video Streams | 1 | EventBridge hỗ trợ event buses và content-based rules. MQ dành cho broker compatibility. SQS Long Polling và Video Streams không đáp ứng event routing đa nguồn.
INT-EX06 | single_choice | Một order workflow có bước reserve stock, charge payment và create shipment. Nếu payment thất bại, hệ thống phải retry rồi chạy compensation. Chọn gì? | SNS Standard | SQS Delay Queue | AWS Step Functions Standard | Kinesis Firehose | 3 | Step Functions Standard phù hợp workflow nhiều bước với retry, catch và compensation. SNS/SQS chỉ truyền message. Firehose delivery streaming data.
INT-EX07 | single_choice | Một IoT platform chạy hàng triệu workflows ngắn, mỗi workflow hoàn thành trong vài giây. Yêu cầu throughput cao và tối ưu cho short executions. Chọn gì? | Step Functions Standard | Amazon MQ | SQS FIFO | Step Functions Express | 4 | Express phù hợp short high-volume workflows. Standard dành cho long-running workflows. MQ và SQS không cung cấp orchestration tương đương.
INT-EX08 | single_choice | Một công ty muốn migrate hệ thống RabbitMQ lên AWS với thay đổi application code ít nhất. Chọn gì? | EventBridge | Amazon MQ | SQS Standard | SNS | 2 | Amazon MQ hỗ trợ RabbitMQ compatibility và giảm rewrite. EventBridge, SQS và SNS sử dụng messaging model khác.
INT-EX09 | single_choice | Một fraud detection platform cần ingest transaction stream real-time, nhiều consumer độc lập và replay dữ liệu để chạy lại thuật toán. Chọn gì? | Kinesis Data Streams | Amazon SQS | Kinesis Firehose | AWS Batch | 1 | Data Streams hỗ trợ real-time processing, multiple consumers và replay. SQS là work queue. Firehose có buffering. Batch xử lý jobs.
INT-EX10 | single_choice | Một công ty muốn chuyển logs liên tục vào S3 để xây dựng data lake. Team cần managed scaling, buffering và Lambda transformation. Chọn gì? | SQS FIFO | Step Functions Standard | Kinesis Data Firehose | Amazon MQ | 3 | Firehose hỗ trợ stream delivery đến S3, automatic scaling và transformation. SQS/MQ là messaging. Step Functions điều phối workflow.
INT-EX11 | single_choice | Một mobile chat application cần GraphQL API, real-time subscriptions và offline synchronization. Chọn gì? | Amazon SNS | Amazon SQS | AWS Step Functions | AWS AppSync | 4 | AppSync hỗ trợ GraphQL, subscriptions và offline sync. SNS/SQS là messaging. Step Functions là workflow orchestration.
INT-EX12 | single_choice | Một background processing platform có nhiều poison messages liên tục thất bại. Team muốn cô lập lỗi, điều tra và retry lại sau khi sửa bug. Chọn gì? | Tắt retries | SQS Dead Letter Queue và redrive policy | Tăng Visibility Timeout lên 12 giờ cho mọi message | Chuyển sang Route 53 | 2 | DLQ cô lập poison messages và hỗ trợ redrive. Tắt retry làm mất khả năng phục hồi. Timeout dài không sửa payload lỗi. Route 53 không xử lý queue.
```

---

## 8. So sánh các dịch vụ dễ nhầm trong SAA-C03

| Dịch vụ | Chọn khi | Không nên chọn khi |
| --- | --- | --- |
| SQS Standard | Background jobs, throughput cao | Cần strict ordering |
| SQS FIFO | Ordered processing, deduplication | Không cần ordering, cần throughput tối đa |
| SNS | Pub/Sub, fanout | Cần queue độc lập mà không kết hợp SQS |
| EventBridge | Content-based routing, SaaS events | Chỉ cần simple work queue |
| Step Functions | Multi-step workflow, retry, branching | Chỉ truyền một message |
| Amazon MQ | Migrate ActiveMQ/RabbitMQ | Cloud-native app không cần legacy protocol |
| Kinesis Data Streams | Streaming, replay, multiple consumers | Simple background job |
| Kinesis Data Firehose | Managed delivery đến S3/Redshift | Cần xử lý từng record tức thời |
| AppSync | GraphQL, real-time subscription | Chỉ cần message queue |

---

## 9. TL;DR – Cheatsheet trước kỳ thi

```text
Application Integration
 |
 +-- Messaging
 |    +-- SQS Standard -> High Throughput Queue
 |    +-- SQS FIFO     -> Strict Ordering
 |    +-- Visibility   -> Hide During Processing
 |    +-- DLQ          -> Failed Messages
 |    +-- Idempotency  -> Prevent Duplicate Effects
 |
 +-- Pub/Sub
 |    +-- SNS          -> One-to-Many
 |    +-- SNS + SQS    -> Durable Fanout
 |
 +-- Event Routing
 |    +-- EventBridge  -> Content-Based Routing
 |    +-- Schedule     -> Periodic Events
 |
 +-- Orchestration
 |    +-- Step Functions Standard -> Long Workflow
 |    +-- Step Functions Express  -> Short, High Volume
 |    +-- Choice / Map / Parallel / Retry / Catch
 |
 +-- Legacy Messaging
 |    +-- Amazon MQ    -> RabbitMQ / ActiveMQ
 |
 +-- Streaming
 |    +-- Data Streams -> Real-Time + Replay
 |    +-- Firehose     -> Managed Delivery
 |    +-- Analytics    -> Stream Processing
 |    +-- Video Streams-> Video Ingestion
 |
 +-- GraphQL
      +-- AppSync      -> Real-Time + Offline Sync
```

Sau bài này, bạn cần làm được: Thiết kế asynchronous architecture, lựa chọn đúng messaging/streaming service, xử lý duplicate messages và retries, xây dựng SNS fanout, điều phối workflow bằng Step Functions và phân tích trade-offs thường gặp trong đề thi AWS SAA-C03.
